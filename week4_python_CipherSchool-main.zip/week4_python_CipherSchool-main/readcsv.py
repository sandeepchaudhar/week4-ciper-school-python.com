from csv import reader

with open('file.csv','r')as f: