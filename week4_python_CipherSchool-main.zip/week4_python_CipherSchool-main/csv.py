from csv import

with open('file.csv','r')as f:
